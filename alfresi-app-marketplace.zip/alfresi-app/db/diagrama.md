# Diagrama entidad-relación · Alfresi.app

GitHub dibuja este diagrama automáticamente (Mermaid).

```mermaid
erDiagram
    PRODUCTORA ||--o{ MEDICION : registra
    PRODUCTORA ||--o{ PRODUCTO : ofrece
    CATEGORIA ||--o{ PRODUCTO : agrupa
    PRODUCTORA ||--o{ PEDIDO : recibe
    CLIENTE ||--o{ PEDIDO : hace
    PEDIDO ||--|{ DETALLE_PEDIDO : contiene
    PRODUCTO ||--o{ DETALLE_PEDIDO : aparece_en

    PRODUCTORA {
      int id PK
      string nombre
      string responsable
      string municipio
      string telefono
      text descripcion
    }
    MEDICION {
      int id PK
      int productora_id FK
      timestamp fecha_hora
      decimal temperatura
      decimal ph
      decimal conductividad
      text observaciones
    }
    CATEGORIA {
      string id PK
      string nombre
    }
    PRODUCTO {
      int id PK
      int productora_id FK
      string categoria_id FK
      string nombre
      decimal precio
      string unidad
      int stock
      bool activo
      text foto_url
      timestamp publicado_en
    }
    CLIENTE {
      int id PK
      string nombre
      string telefono
      string correo
      string direccion
    }
    PEDIDO {
      int id PK
      int productora_id FK
      int cliente_id FK
      timestamp fecha
      enum estado
      string direccion
    }
    DETALLE_PEDIDO {
      int id PK
      int pedido_id FK
      int producto_id FK
      int cantidad
      decimal precio_unitario
    }
```

| Tabla | Historia | Para qué sirve |
|---|---|---|
| `productora` | Todas | Datos de la finca y contacto directo; origen de las fresas en el catálogo |
| `medicion` | HU-01 | Temperatura, pH y nutrientes (conductividad) con fecha y hora automáticas |
| `categoria` | HU-03 | Categorías del Marketplace (fresa fresca, canastas, procesados, plántulas) |
| `producto` | HU-03 / HU-02 | Publicaciones: foto, precio, unidad, inventario y si está activa o pausada |
| `cliente` | HU-02 | Quién hace el pedido y cómo contactarlo |
| `pedido` | HU-02 | Pedido con estado: recibido, en preparación, entregado o cancelado |
| `detalle_pedido` | HU-02 | Productos y cantidades de cada pedido, con el precio del momento |
