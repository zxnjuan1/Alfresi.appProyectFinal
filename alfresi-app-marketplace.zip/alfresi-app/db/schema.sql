-- =====================================================================
-- Alfresi.app · Esquema de base de datos (v2 · marketplace funcional)
-- Motor objetivo: PostgreSQL (compatible con Supabase)
-- Cubre las tres historias: HU-01 cultivo, HU-02 pedidos, HU-03 catálogo
-- =====================================================================

-- Productora (finca). Piloto con una sola, pero el modelo permite escalar a varias.
CREATE TABLE productora (
  id            SERIAL PRIMARY KEY,
  nombre        VARCHAR(120) NOT NULL,
  responsable   VARCHAR(120) NOT NULL,
  municipio     VARCHAR(80)  NOT NULL DEFAULT 'Guasca',
  departamento  VARCHAR(80)  NOT NULL DEFAULT 'Cundinamarca',
  telefono      VARCHAR(30)  NOT NULL,          -- contacto directo (WhatsApp)
  correo        VARCHAR(120),
  descripcion   TEXT,                           -- información de origen para el catálogo
  miembro_desde DATE         NOT NULL DEFAULT CURRENT_DATE,
  creado_en     TIMESTAMP    NOT NULL DEFAULT NOW()
);

-- HU-01 · Mediciones de la solución nutritiva
CREATE TABLE medicion (
  id             SERIAL PRIMARY KEY,
  productora_id  INT          NOT NULL REFERENCES productora(id) ON DELETE CASCADE,
  fecha_hora     TIMESTAMP    NOT NULL DEFAULT NOW(),   -- fecha y hora automáticas
  temperatura    NUMERIC(4,1) NOT NULL,                 -- °C
  ph             NUMERIC(3,1) NOT NULL CHECK (ph BETWEEN 0 AND 14),
  conductividad  NUMERIC(4,2) NOT NULL CHECK (conductividad >= 0), -- nutrientes, mS/cm
  observaciones  TEXT
);
CREATE INDEX idx_medicion_fecha ON medicion (productora_id, fecha_hora DESC);

-- HU-03 · Categorías del Marketplace
CREATE TABLE categoria (
  id      VARCHAR(30) PRIMARY KEY,    -- 'fresca', 'canastas', 'procesados', 'plantulas'
  nombre  VARCHAR(60) NOT NULL,
  icono   VARCHAR(8)
);

-- HU-03 · Publicaciones (productos) del Marketplace
CREATE TABLE producto (
  id             SERIAL PRIMARY KEY,
  productora_id  INT           NOT NULL REFERENCES productora(id) ON DELETE CASCADE,
  categoria_id   VARCHAR(30)   NOT NULL REFERENCES categoria(id),
  nombre         VARCHAR(120)  NOT NULL,
  descripcion    TEXT,
  precio         NUMERIC(10,0) NOT NULL CHECK (precio >= 0),  -- pesos colombianos
  unidad         VARCHAR(20)   NOT NULL DEFAULT 'kg',         -- kg, canasta, frasco...
  stock          INT           NOT NULL DEFAULT 0 CHECK (stock >= 0),
  activo         BOOLEAN       NOT NULL DEFAULT TRUE,         -- FALSE = publicación pausada
  foto_url       TEXT,
  publicado_en   TIMESTAMP     NOT NULL DEFAULT NOW(),
  actualizado_en TIMESTAMP     NOT NULL DEFAULT NOW()
);

-- Clientes que hacen pedidos
CREATE TABLE cliente (
  id         SERIAL PRIMARY KEY,
  nombre     VARCHAR(120) NOT NULL,
  telefono   VARCHAR(30)  NOT NULL,
  correo     VARCHAR(120),
  direccion  VARCHAR(200),
  creado_en  TIMESTAMP    NOT NULL DEFAULT NOW()
);

-- HU-02 · Pedidos
CREATE TYPE estado_pedido AS ENUM ('recibido', 'en_preparacion', 'entregado', 'cancelado');

CREATE TABLE pedido (
  id             SERIAL PRIMARY KEY,
  productora_id  INT           NOT NULL REFERENCES productora(id),
  cliente_id     INT           NOT NULL REFERENCES cliente(id),
  fecha          TIMESTAMP     NOT NULL DEFAULT NOW(),
  estado         estado_pedido NOT NULL DEFAULT 'recibido',
  direccion      VARCHAR(200),               -- punto de entrega de este pedido
  notas          TEXT
);

-- Un producto está disponible para pedir si activo = TRUE y stock > 0
CREATE VIEW producto_disponible AS
  SELECT *, (activo AND stock > 0) AS disponible FROM producto;

-- Productos y cantidades de cada pedido
CREATE TABLE detalle_pedido (
  id               SERIAL PRIMARY KEY,
  pedido_id        INT           NOT NULL REFERENCES pedido(id) ON DELETE CASCADE,
  producto_id      INT           NOT NULL REFERENCES producto(id),
  cantidad         INT           NOT NULL CHECK (cantidad > 0),
  precio_unitario  NUMERIC(10,0) NOT NULL   -- se guarda el precio del momento de la compra
);

-- ---------------------------------------------------------------------
-- Datos de ejemplo (los mismos de src/data/mockData.js)
-- ---------------------------------------------------------------------
INSERT INTO productora (nombre, responsable, telefono, descripcion) VALUES
 ('Finca La Esperanza', 'Productora aliada (caso piloto)', '+57 300 698 4889',
  'Cultivo hidropónico de fresas 100% orgánicas a 2.700 m s. n. m., en las veredas de Guasca.');

INSERT INTO categoria (id, nombre, icono) VALUES
 ('fresca', 'Fresa fresca', '🍓'), ('canastas', 'Canastas', '🧺'), ('procesados', 'Procesados', '🫙'), ('plantulas', 'Plántulas', '🌱');

INSERT INTO producto (productora_id, categoria_id, nombre, descripcion, precio, unidad, stock) VALUES
 (1, 'fresca', 'Fresa orgánica premium', 'Fruta grande y dulce, seleccionada a mano.', 14000, 'kg', 25),
 (1, 'fresca', 'Fresa para jugos', 'Fruta madura, ideal para jugos y batidos.', 9000, 'kg', 40),
 (1, 'canastas', 'Canasta familiar 2 kg', 'Canasta de 2 kg de fresa mixta para la semana.', 25000, 'canasta', 8),
 (1, 'procesados', 'Mermelada artesanal 250 g', 'Preparada con fresa de la finca y panela.', 16000, 'frasco', 0),
 (1, 'procesados', 'Fresa deshidratada', 'Snack natural sin azúcar añadida.', 12000, 'bolsa', 15),
 (1, 'plantulas', 'Plántula de fresa Albión', 'Para huerta en casa, variedad Albión.', 5000, 'unidad', 30),
 (1, 'canastas', 'Caja para restaurantes 5 kg', 'Fresa seleccionada para negocios.', 60000, 'caja', 4),
 (1, 'fresca', 'Fresa pequeña de segunda', 'Fruta sana de tamaño pequeño.', 6000, 'kg', 18);

INSERT INTO medicion (productora_id, fecha_hora, temperatura, ph, conductividad, observaciones) VALUES
 (1, '2026-11-10 07:30', 17.8, 5.9, 1.60, 'Medición de la mañana'),
 (1, '2026-11-09 16:15', 21.4, 6.2, 1.70, NULL),
 (1, '2026-11-09 07:20', 16.9, 6.6, 1.40, 'pH alto, revisar dosificación'),
 (1, '2026-11-08 07:45', 17.2, 6.0, 1.50, NULL);

INSERT INTO cliente (nombre, telefono) VALUES
 ('María Rodríguez', '310 555 0101'), ('Café Guasca', '320 555 0202'), ('Andrés Gómez', '315 555 0303');

INSERT INTO pedido (productora_id, cliente_id, fecha, estado) VALUES
 (1, 1, '2026-11-10', 'recibido'), (1, 2, '2026-11-09', 'en_preparacion'), (1, 3, '2026-11-08', 'entregado');

INSERT INTO detalle_pedido (pedido_id, producto_id, cantidad, precio_unitario) VALUES
 (1, 1, 2, 14000), (2, 2, 10, 9000), (3, 5, 3, 12000);
