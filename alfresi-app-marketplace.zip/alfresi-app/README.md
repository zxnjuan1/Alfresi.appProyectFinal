# 🍓 Alfresi.app — Marketplace de fresas de Guasca

Plataforma tipo marketplace para que las productoras de fresas orgánicas de Guasca, Cundinamarca vendan directo a sus clientes y controlen su cultivo.
Parte del boceto [zxnjuan1/Alfresi.app](https://github.com/zxnjuan1/Alfresi.app) (landing y product backlog).

## Qué hace

### Para los clientes (Comprar)
- **Explorar** publicaciones en cuadrícula con foto, precio, unidad y ubicación. Las agotadas o pausadas se marcan.
- **Buscar** por texto (sin importar tildes), **filtrar** por categoría, rango de precio y "solo disponibles". Los filtros quedan en la URL, así se pueden compartir.
- **Ver el detalle** de cada producto: foto grande, detalles, inventario, información y origen de la productora, productos similares y botón para compartir.
- **Hacer un pedido**: cantidad, nombre, teléfono, punto de entrega y notas. No se puede pedir más de lo que hay.
- **Mensaje a la productora** ("Hola, ¿sigue disponible?") que abre WhatsApp.
- **Mis pedidos**: seguimiento del estado (recibido → en preparación → entregado).

### Para la productora (Vender)
- **Mis publicaciones**: resumen (disponibles, pedidos por atender, total vendido), ajustar inventario con + / −, pausar, reactivar, editar y eliminar.
- **Crear / editar publicación** con foto desde el celular (se comprime sola) o una ilustración, y vista previa en vivo.
- **Pedidos** por pestañas de estado. Avanzar estado, cancelar (devuelve el inventario) o reabrir. El teléfono del cliente abre WhatsApp.
- **Registro de cultivo (HU-01)**: temperatura, pH y nutrientes con fecha y hora automáticas, indicadores con alerta si algo está fuera de rango, mini gráficas de tendencia, historial filtrable por periodo.
- **Perfil de la finca**: nombre, WhatsApp, ubicación y origen de las fresas (aparece en cada publicación).
- **Restablecer datos de ejemplo** para volver a empezar la demo.

## Cómo se guardan los datos

Todo se guarda en el navegador (`localStorage`) a través de un único archivo: `src/data/store.js`.
Los datos se mantienen al recargar y se sincronizan entre pestañas, pero **cada dispositivo tiene su propia copia**:
un pedido hecho en el celular de un cliente no le llega a la productora en otro dispositivo.

Para que sea multiusuario hay que conectar una base de datos real (por ejemplo Supabase con `db/schema.sql`).
Solo hay que reescribir las funciones de `store.js` (`guardarProducto`, `crearPedido`, `cambiarEstadoPedido`, `crearMedicion`…); las pantallas no cambian.

## Cómo abrirla

**Sin instalar nada:** abre `Alfresi.html` con doble clic (Chrome, Edge o Firefox). Es la app completa en un solo archivo.

> ⚠️ No abras el `index.html` de la carpeta principal con doble clic: ese es el código fuente y se ve en blanco.
> Para trabajar en el código usa `npm run dev` (abajo).

## Cómo correrla (para programar)

Necesitas [Node.js](https://nodejs.org) 20 o superior.

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # genera dist/index.html: la app completa en un solo archivo
```

Base de datos (PostgreSQL / Supabase): `psql -d alfresi -f db/schema.sql`

## Estructura

```
src/
  App.jsx                    rutas
  data/store.js              capa de datos (guardar, pedir, cambiar estado, medir)
  data/mockData.js           datos de ejemplo y rangos de referencia del cultivo
  components/                Layout (barra superior + lateral), TarjetaPublicacion, Foto, Toast, Icono, EstadoPedido
  pages/                     Explorar, Item (detalle + pedido), MisPedidos
  pages/vender/              Publicaciones, EditorPublicacion, PedidosRecibidos, Cultivo, Perfil
db/schema.sql                tablas + vista producto_disponible + datos de ejemplo
db/diagrama.md               diagrama entidad-relación (Mermaid)
docs/wireframes.md           wireframes del Sprint 1
```

## Rutas

| Ruta | Pantalla |
|---|---|
| `#/` | Explorar (con `?q=`, `?cat=`, `?min=`, `?max=`, `?disp=1`) |
| `#/item/:id` | Detalle y pedido |
| `#/mis-pedidos` | Pedidos del cliente |
| `#/vender` | Mis publicaciones |
| `#/vender/publicar`, `#/vender/editar/:id` | Crear / editar publicación |
| `#/vender/pedidos` | Pedidos recibidos |
| `#/vender/cultivo` | Registro de cultivo |
| `#/vender/perfil` | Perfil de la finca |

## Pendiente

- Base de datos compartida (Supabase) para que clientes y productora vean los mismos datos.
- Inicio de sesión para la productora: hoy cualquiera puede entrar a "Vender".
- Fotos reales de los productos (por ahora hay ilustraciones de ejemplo).

Equipo: Juan David Pinzón, Juan Camilo Almanza, Allison Farias Quemba.
