# Wireframes · Sprint 1

Pantallas principales en versión celular (la mayoría de clientes y la productora usarán el teléfono).
En escritorio el contenido se reparte en columnas; ver la app en `npm run dev`.

## Navegación (todas las pantallas)

```
┌──────────────────────────────┐
│ 🍓 Alfresi.app          [☰]  │  ← en escritorio: Inicio · Catálogo · Registro de cultivo · Pedidos
└──────────────────────────────┘
```

## 1. Inicio  `/`

```
┌──────────────────────────────┐
│ GUASCA, CUNDINAMARCA         │
│ Fresas orgánicas, directo    │
│ del campo a tu mesa      🍓  │
│ Texto corto de la propuesta  │
│ [ Ver catálogo ] [Soy prod.] │
└──────────────────────────────┘
 ¿Qué puedes hacer?
┌──────────────────────────────┐
│ 🛒 Catálogo          HU-03   │
│ Fotos, precios, disponib.  → │
├──────────────────────────────┤
│ 🌡️ Registro de cultivo HU-01 │
│ Temp., pH y nutrientes     → │
├──────────────────────────────┤
│ 📦 Pedidos           HU-02   │
│ Organizar pedidos          → │
└──────────────────────────────┘
```

## 2. Catálogo  `/catalogo`  (HU-03)

```
 HU-03 · CLIENTES
 Catálogo de productos
 [✓] Mostrar solo disponibles      6 productos
┌──────────────────────────────┐
│        [ FOTO PRODUCTO ]     │
│ (Disponible · 25 kg)         │
│ Fresa orgánica premium       │
│ Descripción corta            │
│ $14.000 / kg                 │
└──────────────────────────────┘
┌──────────────────────────────┐
│        [ FOTO PRODUCTO ]     │
│ (Agotado)                    │
│ ...                          │
└──────────────────────────────┘
┌──────────────────────────────┐
│ DE DÓNDE VIENEN              │
│ Finca La Esperanza, Guasca   │
│ [ Contactar a la productora ]│ ← abre WhatsApp
└──────────────────────────────┘
```

## 3. Registro de cultivo  `/registro-cultivo`  (HU-01)

```
 HU-01 · PRODUCTORA
 Registro de cultivo
┌──────────────────────────────┐
│ Nueva medición               │
│ Temperatura (°C)  [______]   │
│ pH                [______]   │
│ Nutrientes mS/cm  [______]   │
│ Observaciones     [______]   │
│ [     Guardar medición     ] │  ← fecha y hora automáticas
└──────────────────────────────┘
┌──────────────────────────────┐
│ Mediciones anteriores        │
│ Fecha/hora | T° | pH | mS/cm │
│ 10 nov 7:30| 17.8| 5.9| 1.6  │
│ 09 nov 7:20| 16.9|*6.6*| 1.4 │ ← fuera de rango en rojo
└──────────────────────────────┘
```

## 4. Pedidos  `/pedidos`  (HU-02)

```
 HU-02 · PRODUCTORA
 Pedidos
┌────────┬────────┬────────┐
│ 1      │ 1      │ 1      │
│Recibid.│En prep.│Entreg. │
└────────┴────────┴────────┘
 [Todos los estados ▾]   3 pedidos
┌──────────────────────────────┐
│ Pedido #1001     (Recibido)  │
│ María R. · 310... · 10 nov   │
│ • 2 × Fresa premium (kg)     │
│ • 1 × Canasta familiar       │
│ Total: $53.000  [Estado ▾]   │
└──────────────────────────────┘
```
