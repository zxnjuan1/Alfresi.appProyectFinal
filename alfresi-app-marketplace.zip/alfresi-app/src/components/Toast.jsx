import { useEffect, useState } from 'react'

let avisar = () => {}
/** Muestra un mensaje corto en la parte inferior de la pantalla. */
export const toast = (texto) => avisar(texto)

export default function Toast() {
  const [texto, setTexto] = useState(null)
  useEffect(() => {
    let t
    avisar = (msg) => { setTexto(msg); clearTimeout(t); t = setTimeout(() => setTexto(null), 3200) }
    return () => clearTimeout(t)
  }, [])
  return texto ? <div className="toast" role="status">{texto}</div> : null
}
