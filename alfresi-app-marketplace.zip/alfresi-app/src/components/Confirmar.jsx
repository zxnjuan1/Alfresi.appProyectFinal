import { useEffect, useState } from 'react'

let abrir = () => Promise.resolve(false)
/** Diálogo de confirmación propio (reemplaza window.confirm). Devuelve una promesa con true/false. */
export const confirmar = (texto, { aceptar = 'Confirmar', peligro = false } = {}) => abrir(texto, aceptar, peligro)

export default function Confirmar() {
  const [dlg, setDlg] = useState(null)
  useEffect(() => {
    abrir = (texto, aceptar, peligro) => new Promise((resolve) => setDlg({ texto, aceptar, peligro, resolve }))
  }, [])
  if (!dlg) return null
  const cerrar = (v) => { dlg.resolve(v); setDlg(null) }
  return (
    <div className="dialogo-fondo" onClick={() => cerrar(false)}>
      <div className="dialogo" role="alertdialog" aria-modal="true" onClick={(e) => e.stopPropagation()}>
        <p>{dlg.texto}</p>
        <div className="dialogo-botones">
          <button className="boton boton-suave" onClick={() => cerrar(false)} autoFocus>Volver</button>
          <button className={`boton ${dlg.peligro ? 'boton-peligro' : 'boton-primario'}`} onClick={() => cerrar(true)}>{dlg.aceptar}</button>
        </div>
      </div>
    </div>
  )
}
