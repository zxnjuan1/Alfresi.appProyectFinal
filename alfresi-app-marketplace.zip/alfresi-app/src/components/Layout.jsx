import { useEffect, useState } from 'react'
import { Link, NavLink, Outlet, useLocation, useNavigate, useSearchParams } from 'react-router-dom'
import Icono from './Icono.jsx'
import Toast, { toast } from './Toast.jsx'
import Confirmar, { confirmar } from './Confirmar.jsx'
import { categorias } from '../data/mockData.js'
import { useStore, restablecerDemo } from '../data/store.js'

function Marca() {
  return (
    <Link to="/" className="marca" aria-label="Alfresi, inicio">
      <span className="marca-logo">🍓</span>
      <span className="marca-texto">Alfresi<span>.app</span></span>
    </Link>
  )
}

function Item({ to, icono, children, badge, end }) {
  return (
    <NavLink to={to} end={end} className="side-item">
      <span className="side-icono"><Icono nombre={icono} /></span>
      <span className="side-texto">{children}</span>
      {badge > 0 && <span className="badge">{badge}</span>}
    </NavLink>
  )
}

function SidebarComprador() {
  const { misPedidos = [], pedidos } = useStore()
  const [params, setParams] = useSearchParams()
  const navigate = useNavigate()
  const { pathname } = useLocation()
  const [q, setQ] = useState(params.get('q') ?? '')
  useEffect(() => setQ(params.get('q') ?? ''), [params])

  const activos = pedidos.filter((p) => misPedidos.includes(p.id) && ['recibido', 'en_preparacion'].includes(p.estado)).length

  // Cambia un filtro en la URL; si no estamos en Explorar, lleva allá
  const filtrar = (cambios) => {
    const nuevos = new URLSearchParams(pathname === '/' ? params : undefined)
    Object.entries(cambios).forEach(([k, v]) => (v === '' || v == null || v === false ? nuevos.delete(k) : nuevos.set(k, v)))
    if (pathname === '/') setParams(nuevos)
    else navigate(`/?${nuevos}`)
  }
  const cat = params.get('cat')

  return (
    <>
      <div className="side-cabecera">
        <h1>Marketplace</h1>
      </div>
      <form className="buscador" onSubmit={(e) => { e.preventDefault(); filtrar({ q }) }} role="search">
        <Icono nombre="buscar" tam={18} />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar en Alfresi" aria-label="Buscar productos" />
      </form>

      <nav className="side-nav">
        <Item to="/" icono="tienda" end>Explorar todo</Item>
        <Item to="/mis-pedidos" icono="bolsa" badge={activos}>Mis pedidos</Item>
        <Item to="/vender" icono="etiqueta">Vender</Item>
      </nav>
      <Link to="/vender/publicar" className="boton boton-suave boton-ancho">
        <Icono nombre="mas" tam={18} /> Crear nueva publicación
      </Link>

      <hr />
      <h2 className="side-titulo">Filtros</h2>
      <div className="side-ubicacion">
        <Icono nombre="ubicacion" tam={18} /> Guasca, Cundinamarca · 25 km
      </div>
      <div className="filtro-precio">
        <input type="number" min="0" placeholder="Mín." aria-label="Precio mínimo"
          value={params.get('min') ?? ''} onChange={(e) => filtrar({ min: e.target.value })} />
        <span>a</span>
        <input type="number" min="0" placeholder="Máx." aria-label="Precio máximo"
          value={params.get('max') ?? ''} onChange={(e) => filtrar({ max: e.target.value })} />
      </div>
      <label className="interruptor">
        <span>Solo disponibles</span>
        <input type="checkbox" role="switch" checked={params.get('disp') === '1'} onChange={(e) => filtrar({ disp: e.target.checked ? '1' : '' })} />
      </label>

      <hr />
      <h2 className="side-titulo">Categorías</h2>
      <nav className="side-nav">
        {categorias.map((c) => (
          <button key={c.id} className={`side-item ${cat === c.id ? 'active' : ''}`} onClick={() => filtrar({ cat: cat === c.id ? '' : c.id })}>
            <span className="side-icono emoji">{c.icono}</span>
            <span className="side-texto">{c.nombre}</span>
          </button>
        ))}
      </nav>
    </>
  )
}

function SidebarVendedora() {
  const { pedidos } = useStore()
  const nuevos = pedidos.filter((p) => p.estado === 'recibido').length
  const reiniciar = async () => {
    if (await confirmar('¿Borrar todos los cambios y volver a los datos de ejemplo?', { aceptar: 'Restablecer', peligro: true })) {
      restablecerDemo()
      toast('Se restablecieron los datos de ejemplo')
    }
  }
  return (
    <>
      <div className="side-cabecera">
        <Link to="/" className="volver"><Icono nombre="atras" /> Marketplace</Link>
        <h1>Panel de la productora</h1>
      </div>
      <Link to="/vender/publicar" className="boton boton-primario boton-ancho">
        <Icono nombre="mas" tam={18} /> Crear nueva publicación
      </Link>
      <nav className="side-nav">
        <Item to="/vender" icono="etiqueta" end>Mis publicaciones</Item>
        <Item to="/vender/pedidos" icono="caja" badge={nuevos}>Pedidos</Item>
        <Item to="/vender/cultivo" icono="planta">Registro de cultivo</Item>
        <Item to="/vender/perfil" icono="editar">Perfil de la finca</Item>
      </nav>
      <hr />
      <button className="side-item" onClick={reiniciar}>
        <span className="side-icono"><Icono nombre="reiniciar" /></span>
        <span className="side-texto">Restablecer datos de ejemplo</span>
      </button>
    </>
  )
}

export default function Layout() {
  const { pathname } = useLocation()
  const [menu, setMenu] = useState(false)
  const vendedora = pathname.startsWith('/vender')
  useEffect(() => { setMenu(false); window.scrollTo(0, 0) }, [pathname])

  return (
    <div className="app">
      <header className="topbar">
        <button className="icono-boton solo-movil" onClick={() => setMenu(true)} aria-label="Abrir menú"><Icono nombre="menu" /></button>
        <Marca />
        <nav className="topbar-tabs">
          <NavLink to="/" end className={({ isActive }) => (isActive || (!vendedora && pathname !== '/mis-pedidos') ? 'tab active' : 'tab')}>Comprar</NavLink>
          <NavLink to="/mis-pedidos" className="tab">Mis pedidos</NavLink>
          <NavLink to="/vender" className="tab">Vender</NavLink>
        </nav>
      </header>

      <div className="cuerpo">
        <aside className={`sidebar ${menu ? 'abierto' : ''}`}>
          <button className="icono-boton cerrar-menu solo-movil" onClick={() => setMenu(false)} aria-label="Cerrar menú"><Icono nombre="cerrar" /></button>
          {vendedora ? <SidebarVendedora /> : <SidebarComprador />}
        </aside>
        {menu && <div className="velo" onClick={() => setMenu(false)} />}
        <main className="contenido">
          <Outlet />
        </main>
      </div>
      <Toast />
      <Confirmar />
    </div>
  )
}
