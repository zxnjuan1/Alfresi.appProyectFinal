// Íconos lineales simples (SVG propio)
const trazos = {
  tienda: 'M3 9l1.5-5h15L21 9M3 9h18M3 9v11h18V9M9 20v-6h6v6',
  buscar: 'M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14zM21 21l-5-5',
  bolsa: 'M5 8h14l-1 12H6L5 8zM9 8V6a3 3 0 0 1 6 0v2',
  etiqueta: 'M3 12V4h8l10 10-8 8L3 12zM7.5 7.5h.01',
  caja: 'M3 7l9-4 9 4v10l-9 4-9-4V7zM3 7l9 4 9-4M12 11v10',
  planta: 'M12 21v-9M12 12c0-4 3-7 8-7 0 5-3 8-8 7zM12 14c0-3-2-6-7-6 0 4 3 7 7 6',
  mas: 'M12 5v14M5 12h14',
  ubicacion: 'M12 21s-7-6.5-7-12a7 7 0 0 1 14 0c0 5.5-7 12-7 12zM12 11a2 2 0 1 0 0-4 2 2 0 0 0 0 4z',
  mensaje: 'M4 5h16v11H8l-4 4V5z',
  atras: 'M15 18l-6-6 6-6',
  cerrar: 'M6 6l12 12M18 6L6 18',
  editar: 'M4 20h4L19 9l-4-4L4 16v4z',
  basura: 'M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13',
  compartir: 'M4 12v8h16v-8M12 3v13M7 8l5-5 5 5',
  menu: 'M4 6h16M4 12h16M4 18h16',
  reiniciar: 'M4 4v6h6M20 12a8 8 0 1 1-2.3-5.7L20 8',
}
export default function Icono({ nombre, tam = 20 }) {
  return (
    <svg width={tam} height={tam} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d={trazos[nombre]} />
    </svg>
  )
}
