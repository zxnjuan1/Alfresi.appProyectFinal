import { Link } from 'react-router-dom'
import Foto from './Foto.jsx'
import { formatoPrecio } from '../utils.js'
import { estaDisponible } from '../data/store.js'

export default function TarjetaPublicacion({ producto, ubicacion }) {
  const disponible = estaDisponible(producto)
  return (
    <Link to={`/item/${producto.id}`} className="tarjeta">
      <div className="tarjeta-foto">
        <Foto foto={producto.foto} alt={producto.nombre} />
        {!disponible && <span className="sello">{producto.activo ? 'Agotado' : 'Pausado'}</span>}
      </div>
      <div className="tarjeta-precio">
        {formatoPrecio(producto.precio)} <span className="tarjeta-unidad">/ {producto.unidad}</span>
      </div>
      <div className="tarjeta-titulo">{producto.nombre}</div>
      <div className="tarjeta-lugar">{ubicacion}</div>
    </Link>
  )
}
