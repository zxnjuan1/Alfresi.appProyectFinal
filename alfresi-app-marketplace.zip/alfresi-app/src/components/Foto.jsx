// Muestra la foto real del producto si la productora la subió; si no, una ilustración.
const variantes = {
  roja: { fruto: '#c64654', fondo: '#fbe3df' },
  oscura: { fruto: '#9e2f3c', fondo: '#f6dcd6' },
  mermelada: { fruto: '#b23a48', fondo: '#fdeccf' },
  canasta: { fruto: '#d9535f', fondo: '#e6efdc' },
  deshidratada: { fruto: '#a8584d', fondo: '#f3e6d4' },
  plantula: { fruto: '#7aa35b', fondo: '#e3eedb' },
}
export const VARIANTES = Object.keys(variantes)

export default function Foto({ foto, alt, className = '' }) {
  if (foto?.startsWith('data:') || foto?.startsWith('http')) {
    return <img src={foto} alt={alt} className={`foto ${className}`} />
  }
  const c = variantes[foto] ?? variantes.roja
  return (
    <svg viewBox="0 0 200 200" role="img" aria-label={alt} className={`foto ${className}`} preserveAspectRatio="xMidYMid slice">
      <rect width="200" height="200" fill={c.fondo} />
      <circle cx="165" cy="35" r="55" fill="#fff" opacity="0.45" />
      <path d="M100 62 C146 62 158 98 141 133 C129 157 112 166 100 166 C88 166 71 157 59 133 C42 98 54 62 100 62 Z" fill={c.fruto} />
      {[[82, 92], [112, 88], [97, 112], [76, 124], [121, 120], [100, 140], [86, 150], [114, 148]].map(([x, y], i) => (
        <ellipse key={i} cx={x} cy={y} rx="2.6" ry="3.8" fill="#ffe7a8" opacity="0.9" />
      ))}
      <path d="M100 64 L77 48 L91 61 L70 61 L94 68 Z M100 64 L123 48 L109 61 L130 61 L106 68 Z" fill="#315c3b" />
      <rect x="98" y="40" width="4" height="24" rx="2" fill="#315c3b" />
    </svg>
  )
}
