export const textosEstado = {
  recibido: 'Recibido',
  en_preparacion: 'En preparación',
  entregado: 'Entregado',
  cancelado: 'Cancelado',
}
export default function EstadoPedido({ estado }) {
  return <span className={`chip chip-${estado}`}>{textosEstado[estado]}</span>
}
