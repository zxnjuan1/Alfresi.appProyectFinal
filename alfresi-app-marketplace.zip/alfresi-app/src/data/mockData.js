// Datos semilla: se cargan la primera vez que se abre la app (o al "Restablecer demo").
// Tienen la misma forma que las tablas de db/schema.sql.

const hace = (dias, horas = 0) => new Date(Date.now() - (dias * 24 + horas) * 3600e3).toISOString()

export const categorias = [
  { id: 'fresca', nombre: 'Fresa fresca', icono: '🍓' },
  { id: 'canastas', nombre: 'Canastas', icono: '🧺' },
  { id: 'procesados', nombre: 'Procesados', icono: '🫙' },
  { id: 'plantulas', nombre: 'Plántulas', icono: '🌱' },
]

export const productoraSemilla = {
  id: 1,
  nombre: 'Finca La Esperanza',
  responsable: 'Productora aliada',
  municipio: 'Guasca',
  departamento: 'Cundinamarca',
  telefono: '+57 300 698 4889',
  descripcion:
    'Cultivo hidropónico de fresas 100% orgánicas a 2.700 m s. n. m., en las veredas de Guasca. Cosechamos cada mañana y entregamos en Guasca, La Calera y el norte de Bogotá.',
  miembro_desde: '2025-03-01',
}

export const productosSemilla = [
  { id: 1, categoria: 'fresca', nombre: 'Fresa orgánica premium', descripcion: 'Fruta grande y dulce, seleccionada a mano en la cosecha de la mañana. Ideal para postres y para comer fresca.', precio: 14000, unidad: 'kg', stock: 25, activo: true, foto: 'roja', publicado_en: hace(0, 5) },
  { id: 2, categoria: 'fresca', nombre: 'Fresa para jugos', descripcion: 'Fruta madura de tamaño mediano, perfecta para jugos, batidos y mermeladas caseras.', precio: 9000, unidad: 'kg', stock: 40, activo: true, foto: 'oscura', publicado_en: hace(1, 3) },
  { id: 3, categoria: 'canastas', nombre: 'Canasta familiar 2 kg', descripcion: 'Canasta de 2 kg de fresa mixta para la semana. Se entrega en canasta de mimbre retornable.', precio: 25000, unidad: 'canasta', stock: 8, activo: true, foto: 'canasta', publicado_en: hace(2) },
  { id: 4, categoria: 'procesados', nombre: 'Mermelada artesanal 250 g', descripcion: 'Preparada con fresa de la finca y panela, sin conservantes.', precio: 16000, unidad: 'frasco', stock: 0, activo: true, foto: 'mermelada', publicado_en: hace(4) },
  { id: 5, categoria: 'procesados', nombre: 'Fresa deshidratada', descripcion: 'Snack natural sin azúcar añadida. Bolsa de 100 g.', precio: 12000, unidad: 'bolsa', stock: 15, activo: true, foto: 'deshidratada', publicado_en: hace(5) },
  { id: 6, categoria: 'plantulas', nombre: 'Plántula de fresa Albión', descripcion: 'Para huerta en casa o en materas. Incluye indicaciones de cuidado.', precio: 5000, unidad: 'unidad', stock: 30, activo: true, foto: 'plantula', publicado_en: hace(6) },
  { id: 7, categoria: 'canastas', nombre: 'Caja para restaurantes 5 kg', descripcion: 'Fresa seleccionada para negocios. Entregas martes y viernes.', precio: 60000, unidad: 'caja', stock: 4, activo: true, foto: 'roja', publicado_en: hace(3, 8) },
  { id: 8, categoria: 'fresca', nombre: 'Fresa pequeña de segunda', descripcion: 'Fruta sana de tamaño pequeño, excelente precio para preparaciones.', precio: 6000, unidad: 'kg', stock: 18, activo: true, foto: 'oscura', publicado_en: hace(0, 20) },
]

export const medicionesSemilla = [
  { id: 1, fecha_hora: hace(0, 2), temperatura: 17.8, ph: 5.9, conductividad: 1.6, observaciones: 'Medición de la mañana' },
  { id: 2, fecha_hora: hace(0, 18), temperatura: 21.4, ph: 6.2, conductividad: 1.7, observaciones: '' },
  { id: 3, fecha_hora: hace(1, 2), temperatura: 16.9, ph: 6.6, conductividad: 1.4, observaciones: 'pH alto, revisar dosificación' },
  { id: 4, fecha_hora: hace(1, 18), temperatura: 20.1, ph: 6.1, conductividad: 1.6, observaciones: '' },
  { id: 5, fecha_hora: hace(2, 2), temperatura: 17.2, ph: 6.0, conductividad: 1.5, observaciones: '' },
]

export const pedidosSemilla = [
  { id: 1001, cliente: 'María Rodríguez', telefono: '310 555 0101', direccion: 'Vereda La Concepción, Guasca', notas: '', fecha: hace(0, 3), estado: 'recibido',
    items: [{ producto_id: 1, nombre: 'Fresa orgánica premium', cantidad: 2, precio_unitario: 14000 }] },
  { id: 1002, cliente: 'Café Guasca', telefono: '320 555 0202', direccion: 'Parque principal, Guasca', notas: 'Entregar antes de las 9 a. m.', fecha: hace(1, 4), estado: 'en_preparacion',
    items: [{ producto_id: 2, nombre: 'Fresa para jugos', cantidad: 10, precio_unitario: 9000 }] },
  { id: 1003, cliente: 'Andrés Gómez', telefono: '315 555 0303', direccion: 'La Calera', notas: '', fecha: hace(3), estado: 'entregado',
    items: [{ producto_id: 5, nombre: 'Fresa deshidratada', cantidad: 3, precio_unitario: 12000 }] },
]

// Rangos de referencia para fresa hidropónica (orientativos; confirmar con la productora)
export const rangos = {
  temperatura: { min: 15, max: 24, unidad: '°C', nombre: 'Temperatura' },
  ph: { min: 5.5, max: 6.5, unidad: '', nombre: 'pH' },
  conductividad: { min: 1.0, max: 2.0, unidad: 'mS/cm', nombre: 'Nutrientes' },
}
