// Capa de datos de Alfresi.app.
// Guarda todo en el navegador (localStorage) para que la app funcione sin servidor.
// Todas las pantallas usan SOLO estas funciones: para pasar a una base de datos real
// (Supabase / PostgreSQL con db/schema.sql) basta con reescribir este archivo.
import { useSyncExternalStore } from 'react'
import { productoraSemilla, productosSemilla, pedidosSemilla, medicionesSemilla } from './mockData.js'

// Cambiar la versión de la clave hace que todos vuelvan a cargar los datos semilla
const CLAVE = 'alfresi:v3'

const semilla = () => ({
  productora: productoraSemilla,
  productos: productosSemilla,
  pedidos: pedidosSemilla,
  mediciones: medicionesSemilla,
  misPedidos: [],
})

function leer() {
  try {
    const crudo = localStorage.getItem(CLAVE)
    if (crudo) return JSON.parse(crudo)
  } catch { /* almacenamiento no disponible o dañado: se usa la semilla */ }
  return semilla()
}

let estado = leer()
const oyentes = new Set()

function guardar(nuevo) {
  try {
    localStorage.setItem(CLAVE, JSON.stringify(nuevo))
  } catch (e) {
    if (e?.name === 'QuotaExceededError') throw new Error('No hay espacio para guardar. Usa fotos más livianas.')
    // Si localStorage no está disponible los datos quedan solo en memoria
  }
  estado = nuevo
  oyentes.forEach((fn) => fn())
}

// Sincroniza si la app está abierta en otra pestaña
if (typeof window !== 'undefined') {
  window.addEventListener('storage', (e) => {
    if (e.key === CLAVE) { estado = leer(); oyentes.forEach((fn) => fn()) }
  })
}

const suscribir = (fn) => { oyentes.add(fn); return () => oyentes.delete(fn) }

/** Hook: devuelve el estado completo y se actualiza solo cuando cambia. */
export function useStore() {
  return useSyncExternalStore(suscribir, () => estado)
}

const siguienteId = (lista, minimo = 1) => Math.max(minimo - 1, ...lista.map((x) => x.id)) + 1

// ---------------- Productos (HU-03 / HU-02) ----------------
export const estaDisponible = (p) => p.activo && p.stock > 0

export function guardarProducto(datos) {
  const limpio = {
    ...datos,
    nombre: datos.nombre.trim(),
    descripcion: (datos.descripcion ?? '').trim(),
    precio: Math.max(0, Math.round(Number(datos.precio))),
    stock: Math.max(0, Math.floor(Number(datos.stock))),
  }
  if (!limpio.nombre) throw new Error('El producto necesita un nombre.')
  if (!limpio.precio) throw new Error('El precio debe ser mayor que cero.')

  if (limpio.id) {
    guardar({ ...estado, productos: estado.productos.map((p) => (p.id === limpio.id ? { ...p, ...limpio } : p)) })
    return limpio.id
  }
  const nuevo = { ...limpio, id: siguienteId(estado.productos), activo: true, publicado_en: new Date().toISOString() }
  guardar({ ...estado, productos: [nuevo, ...estado.productos] })
  return nuevo.id
}

export function eliminarProducto(id) {
  guardar({ ...estado, productos: estado.productos.filter((p) => p.id !== id) })
}

// ---------------- Pedidos (HU-02) ----------------
export function crearPedido({ producto_id, cantidad, cliente, telefono, direccion, notas }) {
  const producto = estado.productos.find((p) => p.id === producto_id)
  cantidad = Math.floor(Number(cantidad))
  if (!producto || !estaDisponible(producto)) throw new Error('Este producto ya no está disponible.')
  if (!(cantidad > 0)) throw new Error('La cantidad debe ser al menos 1.')
  if (cantidad > producto.stock) throw new Error(`Solo quedan ${producto.stock} ${producto.unidad} disponibles.`)
  if (!cliente?.trim() || !telefono?.trim()) throw new Error('Escribe tu nombre y tu teléfono.')

  const pedido = {
    id: siguienteId(estado.pedidos, 1001),
    cliente: cliente.trim(),
    telefono: telefono.trim(),
    direccion: (direccion ?? '').trim(),
    notas: (notas ?? '').trim(),
    fecha: new Date().toISOString(),
    estado: 'recibido',
    items: [{ producto_id, nombre: producto.nombre, cantidad, precio_unitario: producto.precio }],
  }
  guardar({
    ...estado,
    pedidos: [pedido, ...estado.pedidos],
    // se descuenta del inventario al hacer el pedido
    productos: estado.productos.map((p) => (p.id === producto_id ? { ...p, stock: p.stock - cantidad } : p)),
    misPedidos: [pedido.id, ...(estado.misPedidos ?? [])],
  })
  return pedido.id
}

export const ESTADOS = ['recibido', 'en_preparacion', 'entregado', 'cancelado']

export function cambiarEstadoPedido(id, nuevoEstado) {
  const pedido = estado.pedidos.find((p) => p.id === id)
  if (!pedido || !ESTADOS.includes(nuevoEstado) || pedido.estado === nuevoEstado) return
  let productos = estado.productos
  // cancelar devuelve el inventario; reactivar un cancelado lo vuelve a descontar
  const ajuste = nuevoEstado === 'cancelado' ? 1 : pedido.estado === 'cancelado' ? -1 : 0
  if (ajuste) {
    productos = productos.map((p) => {
      const item = pedido.items.find((i) => i.producto_id === p.id)
      return item ? { ...p, stock: Math.max(0, p.stock + ajuste * item.cantidad) } : p
    })
  }
  guardar({
    ...estado,
    productos,
    pedidos: estado.pedidos.map((p) => (p.id === id ? { ...p, estado: nuevoEstado } : p)),
  })
}

export const totalPedido = (p) => p.items.reduce((s, i) => s + i.cantidad * i.precio_unitario, 0)

// ---------------- Mediciones (HU-01) ----------------
export function crearMedicion({ temperatura, ph, conductividad, observaciones }) {
  const m = {
    id: siguienteId(estado.mediciones),
    fecha_hora: new Date().toISOString(), // fecha y hora automáticas
    temperatura: Number(temperatura),
    ph: Number(ph),
    conductividad: Number(conductividad),
    observaciones: (observaciones ?? '').trim(),
  }
  if ([m.temperatura, m.ph, m.conductividad].some((v) => Number.isNaN(v))) throw new Error('Revisa los valores.')
  if (m.ph < 0 || m.ph > 14) throw new Error('El pH debe estar entre 0 y 14.')
  if (m.conductividad < 0) throw new Error('Los nutrientes no pueden ser negativos.')
  guardar({ ...estado, mediciones: [m, ...estado.mediciones] })
}

export function eliminarMedicion(id) {
  guardar({ ...estado, mediciones: estado.mediciones.filter((m) => m.id !== id) })
}

// ---------------- Productora ----------------
export function guardarProductora(datos) {
  guardar({ ...estado, productora: { ...estado.productora, ...datos } })
}

// ---------------- Demo ----------------
export function restablecerDemo() {
  guardar(semilla())
}
