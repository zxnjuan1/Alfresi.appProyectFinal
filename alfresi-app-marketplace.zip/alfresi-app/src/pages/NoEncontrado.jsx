import { Link } from 'react-router-dom'
export default function NoEncontrado() {
  return (
    <div className="pagina vacio">
      <span>🍃</span>
      <h3>Esta página no existe</h3>
      <Link to="/" className="boton boton-primario">Volver al Marketplace</Link>
    </div>
  )
}
