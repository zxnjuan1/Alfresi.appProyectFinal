import { Link } from 'react-router-dom'
import EstadoPedido from '../components/EstadoPedido.jsx'
import Foto from '../components/Foto.jsx'
import { useStore, totalPedido } from '../data/store.js'
import { formatoPrecio, haceCuanto, enlaceWhatsApp } from '../utils.js'

const pasos = ['recibido', 'en_preparacion', 'entregado']

export default function MisPedidos() {
  const { pedidos, productos, productora, misPedidos = [] } = useStore()
  const mios = pedidos.filter((p) => misPedidos.includes(p.id))

  return (
    <div className="pagina pagina-angosta">
      <h2>Mis pedidos</h2>
      <p className="texto-secundario">Los pedidos que hiciste desde este dispositivo.</p>
      {mios.length === 0 ? (
        <div className="vacio">
          <span>🧺</span>
          <h3>Aún no has hecho pedidos</h3>
          <p>Explora el Marketplace y pide tus fresas directo a la productora.</p>
          <Link to="/" className="boton boton-primario">Explorar productos</Link>
        </div>
      ) : (
        <div className="lista">
          {mios.map((p) => {
            const item = p.items[0]
            const prod = productos.find((x) => x.id === item.producto_id)
            const paso = pasos.indexOf(p.estado)
            return (
              <article key={p.id} className="tarjeta-pedido">
                <div className="pedido-fila">
                  <Foto foto={prod?.foto} alt={item.nombre} className="miniatura" />
                  <div className="pedido-info">
                    <strong>{item.nombre}</strong>
                    <span className="texto-secundario">{item.cantidad} × {formatoPrecio(item.precio_unitario)} · Pedido #{p.id} · {haceCuanto(p.fecha)}</span>
                    <strong>{formatoPrecio(totalPedido(p))}</strong>
                  </div>
                  <EstadoPedido estado={p.estado} />
                </div>
                {p.estado !== 'cancelado' && (
                  <ol className="progreso">
                    {pasos.map((s, i) => (
                      <li key={s} className={i <= paso ? 'hecho' : ''}>
                        {['Recibido', 'En preparación', 'Entregado'][i]}
                      </li>
                    ))}
                  </ol>
                )}
                <a className="enlace" href={enlaceWhatsApp(productora.telefono, `Hola, pregunto por mi pedido #${p.id}`)} target="_blank" rel="noreferrer">
                  Preguntar a {productora.nombre} por WhatsApp
                </a>
              </article>
            )
          })}
        </div>
      )}
    </div>
  )
}
