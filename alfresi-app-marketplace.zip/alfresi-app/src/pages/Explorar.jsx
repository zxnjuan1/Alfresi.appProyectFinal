import { useSearchParams } from 'react-router-dom'
import TarjetaPublicacion from '../components/TarjetaPublicacion.jsx'
import Icono from '../components/Icono.jsx'
import { useStore, estaDisponible } from '../data/store.js'
import { categorias } from '../data/mockData.js'

const sinTildes = (s) => s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase()

export default function Explorar() {
  const { productos, productora } = useStore()
  const [params, setParams] = useSearchParams()
  const q = params.get('q') ?? ''
  const cat = params.get('cat')
  const min = Number(params.get('min')) || 0
  const max = Number(params.get('max')) || Infinity
  const soloDisp = params.get('disp') === '1'

  const lista = productos
    .filter((p) => p.activo || !soloDisp)
    .filter((p) => !cat || p.categoria === cat)
    .filter((p) => !q || sinTildes(`${p.nombre} ${p.descripcion}`).includes(sinTildes(q)))
    .filter((p) => p.precio >= min && p.precio <= max)
    .filter((p) => !soloDisp || estaDisponible(p))
    // primero lo disponible, luego lo más reciente
    .sort((a, b) => estaDisponible(b) - estaDisponible(a) || b.publicado_en.localeCompare(a.publicado_en))

  const cambiar = (k, v) => {
    const n = new URLSearchParams(params)
    if (v) n.set(k, v)
    else n.delete(k)
    setParams(n)
  }
  const nombreCat = categorias.find((c) => c.id === cat)?.nombre
  const hayFiltros = q || cat || params.get('min') || params.get('max') || soloDisp

  return (
    <div className="pagina">
      {/* En celular la barra lateral está escondida: búsqueda y categorías van arriba */}
      <div className="solo-movil filtros-movil">
        <form className="buscador" onSubmit={(e) => { e.preventDefault(); cambiar('q', new FormData(e.target).get('q')) }}>
          <Icono nombre="buscar" tam={18} />
          <input name="q" defaultValue={q} key={q} placeholder="Buscar en Alfresi" aria-label="Buscar productos" />
        </form>
        <div className="chips-scroll">
          {categorias.map((c) => (
            <button key={c.id} className={`chip-filtro ${cat === c.id ? 'activo' : ''}`} onClick={() => cambiar('cat', cat === c.id ? '' : c.id)}>
              {c.icono} {c.nombre}
            </button>
          ))}
        </div>
      </div>

      <div className="encabezado-lista">
        <h2>{q ? `Resultados para “${q}”` : nombreCat ?? 'Selecciones de hoy'}</h2>
        <span className="ubicacion-link"><Icono nombre="ubicacion" tam={16} /> {productora.municipio} · 25 km</span>
      </div>
      {hayFiltros && (
        <p className="texto-secundario">
          {lista.length} {lista.length === 1 ? 'resultado' : 'resultados'} ·{' '}
          <button className="enlace" onClick={() => setParams({})}>Quitar filtros</button>
        </p>
      )}

      {lista.length ? (
        <div className="grid">
          {lista.map((p) => <TarjetaPublicacion key={p.id} producto={p} ubicacion={`${productora.municipio}, Cund.`} />)}
        </div>
      ) : (
        <div className="vacio">
          <span>🔍</span>
          <h3>No encontramos productos</h3>
          <p>Prueba con otra búsqueda o quita algunos filtros.</p>
        </div>
      )}
    </div>
  )
}
