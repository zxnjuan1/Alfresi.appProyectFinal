import { useState } from 'react'
import { toast } from '../../components/Toast.jsx'
import { confirmar } from '../../components/Confirmar.jsx'
import Icono from '../../components/Icono.jsx'
import { useStore, crearMedicion, eliminarMedicion } from '../../data/store.js'
import { rangos } from '../../data/mockData.js'
import { fechaLegible, haceCuanto } from '../../utils.js'

const CAMPOS = ['temperatura', 'ph', 'conductividad']
const fuera = (campo, v) => v < rangos[campo].min || v > rangos[campo].max
const vacio = { temperatura: '', ph: '', conductividad: '', observaciones: '' }
const PERIODOS = { 7: 'Últimos 7 días', 30: 'Últimos 30 días', 0: 'Todo' }

// Mini gráfica de línea con la franja del rango recomendado
function Tendencia({ campo, datos }) {
  const r = rangos[campo]
  const valores = datos.map((m) => m[campo])
  if (valores.length < 2) return <div className="tendencia vacia">Faltan datos</div>
  const lo = Math.min(r.min, ...valores) * 0.95, hi = Math.max(r.max, ...valores) * 1.05
  const W = 220, H = 56
  const y = (v) => H - ((v - lo) / (hi - lo)) * H
  const x = (i) => (i / (valores.length - 1)) * W
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="tendencia" preserveAspectRatio="none" aria-hidden="true">
      <rect x="0" y={y(r.max)} width={W} height={y(r.min) - y(r.max)} className="franja" />
      <polyline points={valores.map((v, i) => `${x(i)},${y(v)}`).join(' ')} className="linea" />
      {valores.map((v, i) => fuera(campo, v) && <circle key={i} cx={x(i)} cy={y(v)} r="3" className="punto-alerta" />)}
    </svg>
  )
}

export default function Cultivo() {
  const { mediciones } = useStore()
  const [form, setForm] = useState(vacio)
  const [error, setError] = useState('')
  const [periodo, setPeriodo] = useState('7')

  const cambiar = (e) => setForm({ ...form, [e.target.name]: e.target.value })
  const guardar = (e) => {
    e.preventDefault()
    setError('')
    try {
      crearMedicion(form)
      const alertas = CAMPOS.filter((c) => fuera(c, Number(form[c]))).map((c) => rangos[c].nombre)
      toast(alertas.length ? `Guardada. Atención: ${alertas.join(', ')} fuera de rango` : 'Medición guardada')
      setForm(vacio)
    } catch (err) { setError(err.message) }
  }
  const borrar = async (m) => { if (await confirmar('¿Eliminar esta medición?', { aceptar: 'Eliminar', peligro: true })) { eliminarMedicion(m.id); toast('Medición eliminada') } }

  const desde = Number(periodo) ? Date.now() - Number(periodo) * 864e5 : 0
  const filtradas = mediciones.filter((m) => new Date(m.fecha_hora).getTime() >= desde)
  const cronologicas = [...filtradas].reverse()
  const ultima = mediciones[0]

  return (
    <div className="pagina">
      <div className="encabezado-lista">
        <h2>Registro de cultivo</h2>
        <select value={periodo} onChange={(e) => setPeriodo(e.target.value)} aria-label="Periodo">
          {Object.entries(PERIODOS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </select>
      </div>

      <div className="indicadores">
        {CAMPOS.map((c) => {
          const v = ultima?.[c]
          const mal = ultima && fuera(c, v)
          return (
            <div key={c} className={`indicador ${mal ? 'alerta' : ''}`}>
              <span className="texto-secundario">{rangos[c].nombre}</span>
              <strong>{v ?? '—'} <small>{rangos[c].unidad}</small></strong>
              <span className={mal ? 'estado-mal' : 'estado-ok'}>
                {ultima ? (mal ? 'Fuera de rango' : 'En rango') : 'Sin datos'} · {rangos[c].min}–{rangos[c].max}
              </span>
              <Tendencia campo={c} datos={cronologicas} />
            </div>
          )
        })}
      </div>
      {ultima && <p className="texto-secundario">Última medición {haceCuanto(ultima.fecha_hora)}</p>}

      <div className="cultivo-layout">
        <form className="panel formulario" onSubmit={guardar}>
          <h3>Nueva medición</h3>
          <label className="campo"><span>Temperatura (°C)</span>
            <input name="temperatura" type="number" step="0.1" required value={form.temperatura} onChange={cambiar} placeholder="18.5" /></label>
          <label className="campo"><span>pH</span>
            <input name="ph" type="number" step="0.1" min="0" max="14" required value={form.ph} onChange={cambiar} placeholder="6.0" /></label>
          <label className="campo"><span>Nutrientes · conductividad (mS/cm)</span>
            <input name="conductividad" type="number" step="0.1" min="0" required value={form.conductividad} onChange={cambiar} placeholder="1.6" /></label>
          <label className="campo"><span>Observaciones</span>
            <textarea name="observaciones" rows="2" value={form.observaciones} onChange={cambiar} placeholder="Opcional" /></label>
          {error && <p className="error">{error}</p>}
          <button className="boton boton-primario boton-ancho" type="submit">Guardar medición</button>
          <p className="texto-secundario pequeño">La fecha y la hora se registran automáticamente.</p>
        </form>

        <div className="panel">
          <h3>Historial ({filtradas.length})</h3>
          <div className="tabla-scroll">
            <table>
              <thead><tr><th>Fecha y hora</th><th>Temp.</th><th>pH</th><th>Nutrientes</th><th>Observaciones</th><th></th></tr></thead>
              <tbody>
                {filtradas.map((m) => (
                  <tr key={m.id}>
                    <td>{fechaLegible(m.fecha_hora)}</td>
                    {CAMPOS.map((c) => <td key={c} className={fuera(c, m[c]) ? 'alerta' : ''}>{m[c]} {rangos[c].unidad}</td>)}
                    <td className="obs">{m.observaciones || '—'}</td>
                    <td><button className="icono-boton" onClick={() => borrar(m)} aria-label="Eliminar medición"><Icono nombre="basura" tam={16} /></button></td>
                  </tr>
                ))}
                {filtradas.length === 0 && <tr><td colSpan="6" className="texto-secundario">No hay mediciones en este periodo.</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )
}
