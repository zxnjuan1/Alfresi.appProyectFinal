import { useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import Foto, { VARIANTES } from '../../components/Foto.jsx'
import { toast } from '../../components/Toast.jsx'
import { useStore, guardarProducto } from '../../data/store.js'
import { categorias } from '../../data/mockData.js'
import { comprimirFoto, formatoPrecio } from '../../utils.js'

const UNIDADES = ['kg', 'libra', 'canasta', 'caja', 'frasco', 'bolsa', 'unidad']

export default function EditorPublicacion() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { productos, productora } = useStore()
  const existente = productos.find((p) => p.id === Number(id))
  const [form, setForm] = useState(
    existente ?? { nombre: '', precio: '', unidad: 'kg', categoria: 'fresca', stock: 10, descripcion: '', foto: 'roja' },
  )
  const [error, setError] = useState('')
  const cambiar = (e) => setForm({ ...form, [e.target.name]: e.target.value })

  const subirFoto = async (e) => {
    const archivo = e.target.files?.[0]
    if (!archivo) return
    try {
      const foto = await comprimirFoto(archivo)
      setForm((f) => ({ ...f, foto }))
    } catch (err) { setError(err.message) }
  }

  const enviar = (e) => {
    e.preventDefault()
    try {
      const nuevoId = guardarProducto(form)
      toast(existente ? 'Cambios guardados' : 'Tu publicación ya está en el Marketplace')
      navigate(existente ? '/vender' : `/item/${nuevoId}`)
    } catch (err) { setError(err.message) }
  }

  return (
    <div className="editor">
      <form className="editor-form" onSubmit={enviar}>
        <h2>{existente ? 'Editar publicación' : 'Artículo en venta'}</h2>

        <div className="fotos-subir">
          <label className="subir">
            <input type="file" accept="image/*" onChange={subirFoto} hidden />
            <span>📷</span>
            <strong>Agregar foto</strong>
            <small>o arrastra y suelta</small>
          </label>
          <div className="ilustraciones">
            <small className="texto-secundario">O usa una ilustración:</small>
            <div>
              {VARIANTES.map((v) => (
                <button type="button" key={v} className={form.foto === v ? 'sel' : ''} onClick={() => setForm({ ...form, foto: v })} aria-label={`Ilustración ${v}`}>
                  <Foto foto={v} alt="" />
                </button>
              ))}
            </div>
          </div>
        </div>

        <label className="campo"><span>Título</span>
          <input name="nombre" value={form.nombre} onChange={cambiar} required maxLength="80" placeholder="Ej. Fresa orgánica premium" /></label>
        <div className="dos-columnas">
          <label className="campo"><span>Precio (COP)</span>
            <input name="precio" type="number" min="1" step="1" value={form.precio} onChange={cambiar} required /></label>
          <label className="campo"><span>Unidad</span>
            <select name="unidad" value={form.unidad} onChange={cambiar}>{UNIDADES.map((u) => <option key={u}>{u}</option>)}</select></label>
        </div>
        <div className="dos-columnas">
          <label className="campo"><span>Categoría</span>
            <select name="categoria" value={form.categoria} onChange={cambiar}>
              {categorias.map((c) => <option key={c.id} value={c.id}>{c.nombre}</option>)}
            </select></label>
          <label className="campo"><span>Disponibles</span>
            <input name="stock" type="number" min="0" value={form.stock} onChange={cambiar} required /></label>
        </div>
        <label className="campo"><span>Descripción</span>
          <textarea name="descripcion" rows="4" value={form.descripcion} onChange={cambiar} placeholder="Tamaño, sabor, cómo se entrega..." /></label>

        {error && <p className="error">{error}</p>}
        <div className="editor-botones">
          <button type="button" className="boton boton-suave" onClick={() => navigate(-1)}>Cancelar</button>
          <button type="submit" className="boton boton-primario">{existente ? 'Guardar' : 'Publicar'}</button>
        </div>
      </form>

      <section className="editor-vista">
        <p className="texto-secundario"><strong>Vista previa</strong> · así la verán los clientes</p>
        <div className="vista-tarjeta">
          <Foto foto={form.foto} alt="Vista previa" className="vista-foto" />
          <div className="vista-texto">
            <h3>{form.nombre || 'Título'}</h3>
            <div className="item-precio">{form.precio ? formatoPrecio(form.precio) : 'Precio'} <span>/ {form.unidad}</span></div>
            <p className="texto-secundario">Publicado hace un momento en {productora.municipio}</p>
            <h4>Detalles</h4>
            <p className="descripcion">{form.descripcion || 'La descripción aparecerá aquí.'}</p>
            <hr />
            <div className="vendedora">
              <div className="avatar">{productora.nombre[0]}</div>
              <strong>{productora.nombre}</strong>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
