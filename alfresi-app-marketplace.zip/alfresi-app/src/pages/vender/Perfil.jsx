import { useState } from 'react'
import { toast } from '../../components/Toast.jsx'
import { useStore, guardarProductora } from '../../data/store.js'

export default function Perfil() {
  const { productora } = useStore()
  const [form, setForm] = useState(productora)
  const cambiar = (e) => setForm({ ...form, [e.target.name]: e.target.value })
  const enviar = (e) => { e.preventDefault(); guardarProductora(form); toast('Perfil actualizado') }

  return (
    <div className="pagina pagina-angosta">
      <h2>Perfil de la finca</h2>
      <p className="texto-secundario">Esta información aparece en cada publicación, en “Información de la productora”.</p>
      <form className="panel formulario" onSubmit={enviar}>
        <label className="campo"><span>Nombre de la finca</span><input name="nombre" value={form.nombre} onChange={cambiar} required /></label>
        <label className="campo"><span>WhatsApp de contacto</span><input name="telefono" type="tel" value={form.telefono} onChange={cambiar} required /></label>
        <div className="dos-columnas">
          <label className="campo"><span>Municipio</span><input name="municipio" value={form.municipio} onChange={cambiar} required /></label>
          <label className="campo"><span>Departamento</span><input name="departamento" value={form.departamento} onChange={cambiar} required /></label>
        </div>
        <label className="campo"><span>Origen de las fresas</span><textarea name="descripcion" rows="4" value={form.descripcion} onChange={cambiar} /></label>
        <button className="boton boton-primario" type="submit">Guardar cambios</button>
      </form>
    </div>
  )
}
