import { Link } from 'react-router-dom'
import Foto from '../../components/Foto.jsx'
import Icono from '../../components/Icono.jsx'
import { toast } from '../../components/Toast.jsx'
import { confirmar } from '../../components/Confirmar.jsx'
import { useStore, guardarProducto, eliminarProducto, estaDisponible, totalPedido } from '../../data/store.js'
import { formatoPrecio, haceCuanto } from '../../utils.js'

export default function Publicaciones() {
  const { productos, pedidos } = useStore()
  const activas = productos.filter(estaDisponible).length
  const nuevos = pedidos.filter((p) => p.estado === 'recibido').length
  const ventas = pedidos.filter((p) => p.estado === 'entregado').reduce((s, p) => s + totalPedido(p), 0)

  const alternar = (p) => {
    guardarProducto({ ...p, activo: !p.activo })
    toast(p.activo ? 'Publicación pausada: ya no se puede pedir' : 'Publicación activa de nuevo')
  }
  const ajustarStock = (p, delta) => guardarProducto({ ...p, stock: Math.max(0, p.stock + delta) })
  const eliminar = async (p) => {
    if (await confirmar(`¿Eliminar "${p.nombre}"? Esta acción no se puede deshacer.`, { aceptar: 'Eliminar', peligro: true })) {
      eliminarProducto(p.id)
      toast('Publicación eliminada')
    }
  }

  return (
    <div className="pagina">
      <div className="resumen">
        <div><strong>{activas}</strong><span>Publicaciones disponibles</span></div>
        <Link to="/vender/pedidos"><strong>{nuevos}</strong><span>Pedidos por atender</span></Link>
        <div><strong>{formatoPrecio(ventas)}</strong><span>Vendido (entregado)</span></div>
      </div>

      <div className="encabezado-lista">
        <h2>Tus publicaciones</h2>
        <Link to="/vender/publicar" className="boton boton-primario"><Icono nombre="mas" tam={18} /> Publicar</Link>
      </div>

      <div className="lista">
        {productos.map((p) => (
          <article key={p.id} className="fila-publicacion">
            <Link to={`/item/${p.id}`}><Foto foto={p.foto} alt={p.nombre} className="miniatura grande" /></Link>
            <div className="pub-info">
              <Link to={`/item/${p.id}`} className="pub-titulo">{p.nombre}</Link>
              <span className="pub-precio">{formatoPrecio(p.precio)} / {p.unidad}</span>
              <span className="texto-secundario">
                {!p.activo ? '⏸ Pausada' : p.stock === 0 ? '🔴 Agotada' : '🟢 Disponible'} · Publicada {haceCuanto(p.publicado_en)}
              </span>
              <div className="stock">
                <span>Inventario:</span>
                <button onClick={() => ajustarStock(p, -1)} aria-label="Restar uno">−</button>
                <strong>{p.stock}</strong>
                <button onClick={() => ajustarStock(p, 1)} aria-label="Sumar uno">+</button>
                <span className="texto-secundario">{p.unidad}</span>
              </div>
            </div>
            <div className="pub-acciones">
              <Link to={`/vender/editar/${p.id}`} className="boton boton-suave"><Icono nombre="editar" tam={16} /> Editar</Link>
              <button className="boton boton-suave" onClick={() => alternar(p)}>{p.activo ? 'Pausar' : 'Reactivar'}</button>
              <button className="boton boton-suave icono-solo" onClick={() => eliminar(p)} aria-label="Eliminar"><Icono nombre="basura" tam={16} /></button>
            </div>
          </article>
        ))}
      </div>
    </div>
  )
}
