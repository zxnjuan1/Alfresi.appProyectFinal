import { useState } from 'react'
import EstadoPedido, { textosEstado } from '../../components/EstadoPedido.jsx'
import { toast } from '../../components/Toast.jsx'
import { confirmar } from '../../components/Confirmar.jsx'
import { useStore, cambiarEstadoPedido, totalPedido } from '../../data/store.js'
import { formatoPrecio, fechaLegible, haceCuanto, enlaceWhatsApp } from '../../utils.js'

const siguiente = {
  recibido: { estado: 'en_preparacion', texto: 'Empezar a preparar' },
  en_preparacion: { estado: 'entregado', texto: 'Marcar como entregado' },
}
const pestañas = ['recibido', 'en_preparacion', 'entregado', 'cancelado']

export default function PedidosRecibidos() {
  const { pedidos } = useStore()
  const [tab, setTab] = useState('recibido')
  const lista = pedidos.filter((p) => p.estado === tab)

  const mover = async (p, estado) => {
    if (estado === 'cancelado' && !(await confirmar(`¿Cancelar el pedido #${p.id}? El inventario se devuelve.`, { aceptar: 'Cancelar pedido', peligro: true }))) return
    cambiarEstadoPedido(p.id, estado)
    toast(`Pedido #${p.id}: ${textosEstado[estado]}`)
  }

  return (
    <div className="pagina pagina-angosta">
      <h2>Pedidos</h2>
      <div className="pestanas" role="tablist">
        {pestañas.map((t) => (
          <button key={t} role="tab" aria-selected={tab === t} className={tab === t ? 'activa' : ''} onClick={() => setTab(t)}>
            {textosEstado[t]} <span className="conteo">{pedidos.filter((p) => p.estado === t).length}</span>
          </button>
        ))}
      </div>

      {lista.length === 0 ? (
        <div className="vacio"><span>📭</span><h3>No hay pedidos {textosEstado[tab].toLowerCase()}s</h3></div>
      ) : (
        <div className="lista">
          {lista.map((p) => (
            <article key={p.id} className="tarjeta-pedido">
              <div className="pedido-fila">
                <div className="avatar">{p.cliente[0]}</div>
                <div className="pedido-info">
                  <strong>{p.cliente}</strong>
                  <span className="texto-secundario" title={fechaLegible(p.fecha)}>Pedido #{p.id} · {haceCuanto(p.fecha)}</span>
                </div>
                <EstadoPedido estado={p.estado} />
              </div>
              <ul className="items">
                {p.items.map((i) => (
                  <li key={i.producto_id}><span>{i.cantidad} × {i.nombre}</span><span>{formatoPrecio(i.cantidad * i.precio_unitario)}</span></li>
                ))}
                <li className="total"><span>Total</span><span>{formatoPrecio(totalPedido(p))}</span></li>
              </ul>
              <dl className="detalles">
                <dt>Teléfono</dt><dd><a className="enlace" href={enlaceWhatsApp(p.telefono, `Hola ${p.cliente}, te escribo de Alfresi por tu pedido #${p.id}`)} target="_blank" rel="noreferrer">{p.telefono}</a></dd>
                {p.direccion && <><dt>Entrega</dt><dd>{p.direccion}</dd></>}
                {p.notas && <><dt>Notas</dt><dd>{p.notas}</dd></>}
              </dl>
              <div className="pedido-botones">
                {siguiente[p.estado] && (
                  <button className="boton boton-primario" onClick={() => mover(p, siguiente[p.estado].estado)}>{siguiente[p.estado].texto}</button>
                )}
                {['recibido', 'en_preparacion'].includes(p.estado) && (
                  <button className="boton boton-suave" onClick={() => mover(p, 'cancelado')}>Cancelar</button>
                )}
                {p.estado === 'cancelado' && (
                  <button className="boton boton-suave" onClick={() => mover(p, 'recibido')}>Reabrir pedido</button>
                )}
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  )
}
