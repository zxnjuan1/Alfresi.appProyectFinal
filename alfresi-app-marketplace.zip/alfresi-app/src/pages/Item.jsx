import { useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import Foto from '../components/Foto.jsx'
import Icono from '../components/Icono.jsx'
import { toast } from '../components/Toast.jsx'
import TarjetaPublicacion from '../components/TarjetaPublicacion.jsx'
import { useStore, crearPedido, estaDisponible } from '../data/store.js'
import { categorias } from '../data/mockData.js'
import { formatoPrecio, haceCuanto, enlaceWhatsApp } from '../utils.js'

export default function Item() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { productos, productora } = useStore()
  const producto = productos.find((p) => p.id === Number(id))
  const [mensaje, setMensaje] = useState('Hola, ¿sigue disponible?')
  const [pidiendo, setPidiendo] = useState(false)
  const [form, setForm] = useState({ cantidad: 1, cliente: '', telefono: '', direccion: '', notas: '' })
  const [error, setError] = useState('')

  if (!producto) {
    return (
      <div className="pagina vacio">
        <span>🍃</span><h3>Esta publicación ya no existe</h3>
        <Link to="/" className="boton boton-primario">Volver al Marketplace</Link>
      </div>
    )
  }

  const disponible = estaDisponible(producto)
  const categoria = categorias.find((c) => c.id === producto.categoria)
  const similares = productos.filter((p) => p.id !== producto.id && p.categoria === producto.categoria && p.activo).slice(0, 4)
  const cambiar = (e) => setForm({ ...form, [e.target.name]: e.target.value })
  const total = producto.precio * (Number(form.cantidad) || 0)

  const pedir = (e) => {
    e.preventDefault()
    setError('')
    try {
      const nuevo = crearPedido({ producto_id: producto.id, ...form })
      toast(`Pedido #${nuevo} enviado a ${productora.nombre}`)
      navigate('/mis-pedidos')
    } catch (err) {
      setError(err.message)
    }
  }

  const compartir = async () => {
    const url = window.location.href
    try {
      await navigator.share({ title: producto.nombre, url })
    } catch (e) {
      if (e?.name === 'AbortError') return // el usuario cerró el menú de compartir
      try { await navigator.clipboard.writeText(url); toast('Enlace copiado') } catch { toast('No se pudo compartir') }
    }
  }

  return (
    <div className="item">
      <div className="item-galeria">
        <button className="icono-boton item-cerrar" onClick={() => navigate(-1)} aria-label="Volver"><Icono nombre="cerrar" /></button>
        <Foto foto={producto.foto} alt={producto.nombre} className="item-foto" />
      </div>

      <aside className="item-panel">
        <nav className="migas">
          <Link to="/">Marketplace</Link> › <Link to={`/?cat=${producto.categoria}`}>{categoria?.nombre}</Link>
        </nav>
        <h1 className="item-titulo">{producto.nombre}</h1>
        <div className="item-precio">{formatoPrecio(producto.precio)} <span>/ {producto.unidad}</span></div>
        <p className="texto-secundario">Publicado {haceCuanto(producto.publicado_en)} en {productora.municipio}, {productora.departamento}</p>

        <div className="item-acciones">
          {disponible ? (
            <button className="boton boton-primario" onClick={() => setPidiendo(!pidiendo)}>
              <Icono nombre="bolsa" tam={18} /> {pidiendo ? 'Ocultar pedido' : 'Hacer pedido'}
            </button>
          ) : (
            <span className="chip chip-cancelado">{producto.activo ? 'Agotado por ahora' : 'Publicación pausada'}</span>
          )}
          <a className="boton boton-suave" href={enlaceWhatsApp(productora.telefono, `Hola, vi "${producto.nombre}" en Alfresi.`)} target="_blank" rel="noreferrer">
            <Icono nombre="mensaje" tam={18} /> Mensaje
          </a>
          <button className="boton boton-suave icono-solo" onClick={compartir} aria-label="Compartir"><Icono nombre="compartir" tam={18} /></button>
        </div>

        {pidiendo && disponible && (
          <form className="caja-pedido" onSubmit={pedir}>
            <h3>Tu pedido</h3>
            <label className="campo-cantidad">
              Cantidad ({producto.unidad})
              <div className="stepper">
                <button type="button" onClick={() => setForm({ ...form, cantidad: Math.max(1, form.cantidad - 1) })} aria-label="Menos">−</button>
                <input name="cantidad" type="number" min="1" max={producto.stock} value={form.cantidad}
                  onChange={(e) => setForm({ ...form, cantidad: Number(e.target.value) })} />
                <button type="button" onClick={() => setForm({ ...form, cantidad: Math.min(producto.stock, form.cantidad + 1) })} aria-label="Más">+</button>
              </div>
            </label>
            <input name="cliente" placeholder="Tu nombre" value={form.cliente} onChange={cambiar} required />
            <input name="telefono" type="tel" placeholder="Teléfono / WhatsApp" value={form.telefono} onChange={cambiar} required />
            <input name="direccion" placeholder="Dirección o punto de entrega" value={form.direccion} onChange={cambiar} />
            <textarea name="notas" rows="2" placeholder="Notas para la productora (opcional)" value={form.notas} onChange={cambiar} />
            {error && <p className="error">{error}</p>}
            <button className="boton boton-primario boton-ancho" type="submit">Enviar pedido · {formatoPrecio(total)}</button>
            <p className="texto-secundario pequeño">Pagas al recibir. La productora confirma por WhatsApp.</p>
          </form>
        )}

        <section className="item-seccion">
          <h3>Detalles</h3>
          <dl className="detalles">
            <dt>Categoría</dt><dd>{categoria?.icono} {categoria?.nombre}</dd>
            <dt>Disponibles</dt><dd>{producto.stock} {producto.unidad}</dd>
            <dt>Cultivo</dt><dd>Hidropónico, 100% orgánico</dd>
          </dl>
          <p className="descripcion">{producto.descripcion}</p>
        </section>

        <section className="item-seccion">
          <h3>Información de la productora</h3>
          <div className="vendedora">
            <div className="avatar">{productora.nombre[0]}</div>
            <div>
              <strong>{productora.nombre}</strong>
              <p className="texto-secundario">Se unió a Alfresi en {new Date(productora.miembro_desde).getFullYear()} · {productora.municipio}</p>
            </div>
          </div>
          <p className="descripcion">{productora.descripcion}</p>
        </section>

        <section className="item-seccion caja-mensaje">
          <h3><Icono nombre="mensaje" tam={18} /> Envía un mensaje a la productora</h3>
          <input value={mensaje} onChange={(e) => setMensaje(e.target.value)} aria-label="Mensaje" />
          <a className="boton boton-primario boton-ancho" href={enlaceWhatsApp(productora.telefono, `${mensaje} (${producto.nombre})`)} target="_blank" rel="noreferrer">Enviar</a>
        </section>

        {similares.length > 0 && (
          <section className="item-seccion">
            <h3>Productos similares</h3>
            <div className="grid grid-mini">
              {similares.map((p) => <TarjetaPublicacion key={p.id} producto={p} ubicacion={productora.municipio} />)}
            </div>
          </section>
        )}
      </aside>
    </div>
  )
}
