import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout.jsx'
import Explorar from './pages/Explorar.jsx'
import Item from './pages/Item.jsx'
import MisPedidos from './pages/MisPedidos.jsx'
import Publicaciones from './pages/vender/Publicaciones.jsx'
import EditorPublicacion from './pages/vender/EditorPublicacion.jsx'
import PedidosRecibidos from './pages/vender/PedidosRecibidos.jsx'
import Cultivo from './pages/vender/Cultivo.jsx'
import Perfil from './pages/vender/Perfil.jsx'
import NoEncontrado from './pages/NoEncontrado.jsx'

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Explorar />} />
        <Route path="item/:id" element={<Item />} />
        <Route path="mis-pedidos" element={<MisPedidos />} />
        <Route path="vender" element={<Publicaciones />} />
        <Route path="vender/publicar" element={<EditorPublicacion />} />
        <Route path="vender/editar/:id" element={<EditorPublicacion />} />
        <Route path="vender/pedidos" element={<PedidosRecibidos />} />
        <Route path="vender/cultivo" element={<Cultivo />} />
        <Route path="vender/perfil" element={<Perfil />} />
        <Route path="*" element={<NoEncontrado />} />
      </Route>
    </Routes>
  )
}
