import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { viteSingleFile } from 'vite-plugin-singlefile'

// viteSingleFile mete todo (JS + CSS) dentro de dist/index.html:
// ese archivo se puede abrir con doble clic, enviar por correo o subir a GitHub Pages.
export default defineConfig({
  plugins: [react(), viteSingleFile()],
  base: './',
})
